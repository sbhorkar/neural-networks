import java.io.*;
import java.util.*;

/*
 * @author Sanaa Bhorkar
 * @version 03/08/2024
 * 
 * This A-B-C-D perceptron and is built based off of the design document "4-Three Layer Network." 
 * The A-B-C-D network can train a network based off of randomly assigned weights or simply run when given weights from a user. The
 * network trains using gradient descent and back propagation. The program uses a DataOutputStream/DataInputStream to save the
 * weights in a binary format or load them from the binary format. It also uses a BufferedReader and StringTokenizer to read the
 * configuration file.
 * 
 * Format of Configuration File:
 * T                  // R for running, T for training
 * R                  // R for randomized initial weights, P for preloaded initial weights, M for manual inputs in allocateMemory()
 * 2 1 1 3            // number of units in each layer 
 * 4                  // number of test cases
 * 1 1 1 1 0          // truth table
 * 1 0 0 1 1
 * 0 1 0 1 1
 * 0 0 0 0 0
 * 100000             // maximum number of iterations 
 * 2E-4               // minimum error
 * 0.3                // learning rate (lambda)  
 * 0.1 1.5            // random number range
 * weights.txt        // the output file that weights will be saved to (can be omitted to not save weights)
 * initialWeights.txt // the file that the weights will be read from (will be omitted when not loading weights)
 */
public class ABCDNetwork 
{
   public static final int N_LAYERS = 4; // A-B-C-D network will always have 4 layers

   public static String saveWeightsFile;
   public static int nInputs;
   public static int nHidden1;
   public static int nHidden2;       
   public static int nOutputs;           
   public static int testCases;
   public static int maxIterations;
   public static int iterations;
   public static int indexInputLayer;
   public static int indexHiddenLayer1;
   public static int indexHiddenLayer2;
   public static int indexOutputLayer;
   public static int deepestLayer;
   public static double lambda;
   public static double errorCutoff;
   public static double randMin;
   public static double randMax;
   public static double totalError;
   public static double averageError;
   public static double startTime;
   public static double endTime;
   public static boolean training;
   public static boolean randomize;
   public static boolean configNameGiven;
   public static boolean loadWeightsFromFile;
   public static boolean saveWeightsToFile;
   public static String initialWeightsFile;
   public static String configFileName;
   public static double[] a;
   public static double[][] h;
   public static double[] F;
   public static double[] upperThetaHidden1;
   public static double[] upperThetaHidden2;
   public static double[] upperThetaOutput;
   public static double[] lowerPsi;
   public static double[] jUpperPsi;
   public static double[][] mkWeights;
   public static double[][] kjWeights;
   public static double[][] jiWeights;
   public static double[][] truthTableInputs;
   public static double[][] truthTableExpectedOutputs;
   public static double[][] truthTableActualOutputs;

/*
 * The main() method creates an object of the ABCNetwork class and runs its 6 major methods.
 */
   public static void main(String[] args)
   {
      System.out.println(); // Printing clear line before all output to make it easier to read in the terminal.

      ABCDNetwork network = new ABCDNetwork();

      if (args.length > 0)
      {
         network.configureNetwork(args[0]);
      }
      else
      {
         network.configureNetwork(null);
      }

      network.echoParams();
      network.allocateMemory();
      network.populate();

      if (training)
      {
         network.trainNetwork();
         if (saveWeightsFile != null && !saveWeightsFile.equals(""))
         {
            saveWeights();
         }
      }
      
      network.runNetwork();
      network.results();
   } // public static void main(String[] args)

/*
 * The configureNetwork() method is where the user can edit certain parameters of the network such as the configuration, 
 * maxIterations cutoff, error threshold, whether it is training or running, the random number range, and the number of
 * test cases.
 */
   public void configureNetwork(String argGiven) 
   {
      if (argGiven == null)
      {
         configFileName = "configuration.txt"; // default name if no other name is given
      }
      else
      {
         configFileName = argGiven;
      }

      try
      {
         readConfigFile();
      }
      catch (Exception e)
      {
         System.out.println("Exception: " + e);
      }

      if (nHidden1 > nHidden2)
      {
         deepestLayer = nHidden1;
      }
      else
      {
         deepestLayer = nHidden2;
      }

      indexInputLayer = 1;   // input layer is at n = 1
      indexHiddenLayer1 = 2; // hidden layer 1 is at n = 2
      indexHiddenLayer2 = 3; // hidden layer 2 is at n = 3
      indexOutputLayer = 4;  // output layer is at n = 4
   } // public void configureNetwork(String argGiven)

/*
 * The setTruthTable() method reads the configuration file to set the truth table.
 */
   public void setTruthTable()
   {
      int m, i, testCase;
      
      try
      {
         BufferedReader reader = new BufferedReader(new FileReader(configFileName));
         String line = reader.readLine();

/*
 * Need to read the first four lines of the configuration file that have already been read in readConfigFile().
 */
         line = reader.readLine();
         line = reader.readLine();
         line = reader.readLine();
         line = reader.readLine();

         StringTokenizer tokenizer = new StringTokenizer(line);

         for (testCase = 0; testCase < testCases; testCase++)
         {
            for (m = 0; m < nInputs; m++)
            {
               truthTableInputs[testCase][m] = Double.parseDouble(tokenizer.nextToken());
            }

            for (i = 0; i < nOutputs; i++)
            {
               truthTableExpectedOutputs[testCase][i] = Double.parseDouble(tokenizer.nextToken());
            }

            line = reader.readLine();
            tokenizer = new StringTokenizer(line);
         } // for (testCase = 0; testCase < testCases; testCase++)
      } // try
      catch (Exception e)
      {
         System.out.println("Exception " + e.toString());
      }
   } // public void setTruthTable()

/*
 * The echoParams() method prints the network configuration and all other relevant parameters.
 */
   public void echoParams() 
   {
      System.out.println("Network configuration: " + nInputs + "-" + nHidden1 + "-" + nHidden2 + "-" + nOutputs);
      System.out.println("Training?: " + training);
      System.out.println("Randomize weights?: " + randomize);
      System.out.println("Load weights from file?: " + loadWeightsFromFile);
      
      if (!randomize && !loadWeightsFromFile)
      {
         System.out.println("Using manually inputted weights");
      }

      if (saveWeightsFile != null && !saveWeightsFile.equals(""))
      {
         System.out.println("Saving weights to file: " + saveWeightsFile);
      }

      if (loadWeightsFromFile)
      {
         System.out.println("Loading weights from file: " + initialWeightsFile);
      }

      if (training)
      {
         System.out.println("Random number range: " + randMin + " to " + randMax);
         System.out.println("Maximum iterations: " + maxIterations);
         System.out.println("Error threshold: " + errorCutoff);
         System.out.println("Learning factor: " + lambda);
         System.out.println();
      } // if (training)
   } // public void echoParams() 

/*
 * The allocateMemory() method instantiates all the arrays that the network is going to use. Examples of the arrays are the
 * input, hidden, and output activations and all the weights.
 */
   public void allocateMemory() 
   {
      a = new double[nInputs];
      h = new double[N_LAYERS][deepestLayer];
      F = new double[nOutputs];
      mkWeights = new double[nInputs][nHidden1];
      kjWeights = new double[nHidden1][nHidden2];
      jiWeights = new double[nHidden2][nOutputs];
      truthTableInputs = new double[testCases][nInputs];
      truthTableExpectedOutputs = new double[testCases][nOutputs];
      truthTableActualOutputs = new double[testCases][nOutputs];

      if (training)
      {
         upperThetaHidden1 = new double[nHidden1];
         upperThetaHidden2 = new double[nHidden2];
         upperThetaOutput = new double[nOutputs];
         lowerPsi = new double[nOutputs];
         jUpperPsi = new double[nHidden2];
      } // if (training)
   } // public void allocateMemory() 

/*
 * The populate() method populates the weight arrays with either fixed weight values or randomized values, depending on whether 
 * or not the network is training. We assume that "training" the network will use randomized weights while simply running the 
 * network will used fixed weights.
 */
   public void populate() 
   {
      setTruthTable();

      if (loadWeightsFromFile)
      {
         try
         {
            loadWeights();
         }
         catch (Exception e)
         {
            System.out.println("Exception: " + e);
         }
      } // if (loadWeightsFromFile)
      else if (!randomize && !loadWeightsFromFile)
      {
         mkWeights[0][0] = 0.75;
         mkWeights[1][0] = 0.6;

         jiWeights[0][0] = 0.5;
         jiWeights[0][1] = 0.75;
         jiWeights[0][2] = 0.35;
      } // else if (!randomize && !loadWeightsFromFile)
      else
      {
         int m, k, j, i;

         for (m = 0; m < nInputs; m++)
         {
            for (k = 0; k < nHidden1; k++)
            {
               mkWeights[m][k] = randomize(randMin, randMax);
            }
         } // for (m = 0; m < nInputs; m++)

         for (k = 0; k < nHidden1; k++)
         {
            for (j = 0; j < nHidden2; j++)
            {
               kjWeights[k][j] = randomize(randMin, randMax);
            }
         } // for (k = 0; k < nHidden1; k++)

         for (j = 0; j < nHidden2; j++)
         {
            for (i = 0; i < nOutputs; i++)
            {
               jiWeights[j][i] = randomize(randMin, randMax);
            }
         } // for (j = 0; j < nHidden; j++)
      } // else
   } // public void populate() 

/*
 * The randomize() method takes in the low and high numbers in the random range and calculates a random number. This method is 
 * used when calculating random weight values.
 */
   public double randomize(double low, double high)
   {
      return low + (high - low) * Math.random();
   }

/*
 * The runNetwork() method goes through the running process for the network. It goes through each
 * test case, sets the input neurons and runs the network. It also calculates the time spent in running.
 */
   public void runNetwork() 
   {
      int truthTableIndex, m, i;

      startTime = System.currentTimeMillis();

      for (truthTableIndex = 0; truthTableIndex < testCases; truthTableIndex++)
      {
         for (m = 0; m < nInputs; m++)
         {
            a[m] = truthTableInputs[truthTableIndex][m];
         }

         run();

         for (i = 0; i < nOutputs; i++)
         {
            truthTableActualOutputs[truthTableIndex][i] = F[i];
         }
      } // for (truthTableIndex = 0; truthTableIndex < testCases; truthTableIndex++)

      endTime = System.currentTimeMillis();
   } // public void runNetwork() 

/*
 * The trainNetwork() method goes through the training process for the network. It goes through each test case, sets the input
 * neurons, runs the network, finds the new weights with backpropagation, runs the network to apply the new weights, calculates
 * the error, and calculates the total time taken for running.
 */
   public void trainNetwork() 
   {
      totalError = 0.0;
      averageError = 0.0;
      iterations = 0;

      boolean done = false;
      
      startTime = System.currentTimeMillis();

      while (!done)
      {
         int truthTableIndex, m, I;

         totalError = 0.0;
         averageError = 0.0;

         for (truthTableIndex = 0; truthTableIndex < testCases; truthTableIndex++)
         {
            for (m = 0; m < nInputs; m++)
            {
               a[m] = truthTableInputs[truthTableIndex][m];
            }

            runForTraining(truthTableIndex);
            trainBackprop();
            run();

            for (I = 0; I < nOutputs; I++)
            {
               double omega = truthTableExpectedOutputs[truthTableIndex][I] - F[I];
               
               totalError += 0.5 * omega * omega;
               truthTableActualOutputs[truthTableIndex][I] = F[I];
            } // for (I = 0; I < nOutputs; I++)
         } // for (truthTableIndex = 0; truthTableIndex < testCases; truthTableIndex++)

         averageError = totalError / ((double) testCases);

         iterations++;

         if (averageError < errorCutoff || iterations > maxIterations)
         {
            done = true;
         }
      } // while (!done)

      endTime = System.currentTimeMillis();
   } // public void trainNetwork() 

/*
 * The runForTraining() method runs the network while saving the theta and psi values, so they are only calculated once.
 */  
   public void runForTraining(int testCase)
   {
      int n, M, k, K, j, J, i;

      n = indexHiddenLayer1;

      for (k = 0; k < nHidden1; k++)
      {
         upperThetaHidden1[k] = 0.0;

         for (M = 0; M < nInputs; M++)
         {
            upperThetaHidden1[k] += a[M] * mkWeights[M][k];
         }

         h[n][k] = activate(upperThetaHidden1[k]);
      }

      for (j = 0; j < nHidden2; j++)
      {
         upperThetaHidden2[j] = 0.0;
         n = indexHiddenLayer1;

         for (K = 0; K < nHidden1; K++)
         {
            upperThetaHidden2[j] += h[n][K] * kjWeights[K][j];
         }

         n = indexHiddenLayer2;
         h[n][j] = activate(upperThetaHidden2[j]);
      } // for (j = 0; j < nHidden; j++)
      
      n = indexHiddenLayer2;

      for (i = 0; i < nOutputs; i++)
      {
         upperThetaOutput[i] = 0.0;

         for (J = 0; J < nHidden2; J++)
         {
            upperThetaOutput[i] += h[n][J] * jiWeights[J][i];
         }

         F[i] = activate(upperThetaOutput[i]);

         double lowerOmega = truthTableExpectedOutputs[testCase][i] - F[i];

         lowerPsi[i] = lowerOmega * derivActivate(upperThetaOutput[i]);
      } // for (i = 0; i < nOutputs; i++)
   } // public void runForTraining(int testCase)

/*
 * The trainBackprop() method finds the new weights by training with backpropagation.
 */
   public void trainBackprop()
   {
      int n, m, k, j, J, I;
      double jUpperOmega, kUpperOmega, kUpperPsi;

      n = indexHiddenLayer2;

      for (j = 0; j < nHidden2; j++)
      {
         jUpperOmega = 0.0;

         for (I = 0; I < nOutputs; I++)
         {
            jUpperOmega += lowerPsi[I] * jiWeights[j][I];
            jiWeights[j][I] += lambda * h[n][j] * lowerPsi[I];
         }

         jUpperPsi[j] = jUpperOmega * derivActivate(upperThetaHidden2[j]);
      }

      n = indexHiddenLayer1;

      for (k = 0; k < nHidden1; k++)
      {
         kUpperOmega = 0.0;

         for (J = 0; J < nHidden2; J++)
         {
            kUpperOmega += jUpperPsi[J] * kjWeights[k][J];
            kjWeights[k][J] += lambda * h[n][k] * jUpperPsi[J];
         }

         kUpperPsi = kUpperOmega * derivActivate(upperThetaHidden1[k]);

         for (m = 0; m < nInputs; m++)
         {
            mkWeights[m][k] += lambda * a[m] * kUpperPsi;
         }
      }
   } // public void trainBackprop()

/*
 * The run() method calculates the hidden and output activations based on the current values in the activations and the weights. 
 */
   public void run()
   {
      int n, M, k, K, j, J, i;

      n = indexHiddenLayer1;

      for (k = 0; k < nHidden1; k++)
      {
         upperThetaHidden1[k] = 0.0;

         for (M = 0; M < nInputs; M++)
         {
            upperThetaHidden1[k] += a[M] * mkWeights[M][k];
         }

         h[n][k] = activate(upperThetaHidden1[k]);
      }

      for (j = 0; j < nHidden2; j++)
      {
         upperThetaHidden2[j] = 0.0;
         n = indexHiddenLayer1;

         for (K = 0; K < nHidden1; K++)
         {
            upperThetaHidden2[j] += h[n][K] * kjWeights[K][j];
         }

         n = indexHiddenLayer2;
         h[n][j] = activate(upperThetaHidden2[j]);
      } // for (j = 0; j < nHidden; j++)
      
      n = indexHiddenLayer2;

      for (i = 0; i < nOutputs; i++)
      {
         upperThetaOutput[i] = 0.0;

         for (J = 0; J < nHidden2; J++)
         {
            upperThetaOutput[i] += h[n][J] * jiWeights[J][i];
         }

         F[i] = activate(upperThetaOutput[i]);
      } // for (i = 0; i < nOutputs; i++)
   } // public void runNetwork()

/*
 * The results() method prints out the training exit info, truth table, and the output values of the network.
 */
   public void results()
   {
      int rowTruthTable, k, i;

      if (training)
      {
         System.out.println("Training Exit Information");
         System.out.println("------------------------------------");

         if (iterations > maxIterations)
         {
            System.out.println("Reason for end of training: Over the max iterations cutoff (" + maxIterations + ").");
         }
         
         if (averageError < errorCutoff)
         {
            System.out.println("Reason for end of training: Average error under the error cutoff (" + errorCutoff + ").");
         }

         System.out.println("Iterations reached: " + iterations);
         System.out.println("Error reached: " + averageError);
      } // if (training)

      System.out.println("Time taken: " + (endTime - startTime) + "ms");
      System.out.println();

      System.out.println("Truth Table");
      System.out.println("------------------------------------");

      for (rowTruthTable = 0; rowTruthTable < testCases; rowTruthTable++)
      {
         String truthTableOutput = "";

         for (k = 0; k < nInputs; k++)
         {
            truthTableOutput += truthTableInputs[rowTruthTable][k] + "\t";
         }

         truthTableOutput += "|\t";

         for (i = 0; i < nOutputs; i++)
         {
            truthTableOutput += truthTableExpectedOutputs[rowTruthTable][i] + "\t";
         }

         truthTableOutput += "|\t";

         for (i = 0; i < nOutputs; i++)
         {
            truthTableOutput += truthTableActualOutputs[rowTruthTable][i] + "\t";
         }

         System.out.println(truthTableOutput);
      } // for (rowTruthTable = 0; rowTruthTable < testCases; rowTruthTable++)
   } // public void results()

/*
 * The activate() method plugs in a given x value into the activation function and returns the result.
 */
   public double activate(double x)
   {
      return 1.0/(1.0 + Math.exp(-x));
   }

/*
 * The derivActivate() method plugs in a given x into the derivative of the activation function and returns the result.
 */
   public double derivActivate(double x)
   {
      double activationFunction = activate(x);

      return activationFunction * (1.0 - activationFunction);
   } // public double derivActivate(double x)

/*
 * The saveWeights() method saves the current weights in an external file.
 */
   public static void saveWeights()
   {
      int m, k, j, i;

      try 
      {
         FileOutputStream fos = new FileOutputStream(saveWeightsFile);
         DataOutputStream dos = new DataOutputStream(fos);

         for (m = 0; m < nInputs; m++)
         {
            for (k = 0; k < nHidden1; k++)
            {
               dos.writeDouble(mkWeights[m][k]);
            }
         } // for (k = 0; k < nInputs; k++)

         for (k = 0; k < nHidden1; k++)
         {
            for (j = 0; j < nHidden2; j++)
            {
               dos.writeDouble(kjWeights[k][j]);
            }
         } // for (k = 0; k < nInputs; k++)

         for (j = 0; j < nHidden2; j++)
         {
            for (i = 0; i < nOutputs; i++)
            {
               dos.writeDouble(jiWeights[j][i]);
            }
         } // for (j = 0; j < nHidden; j++)
      } // try
      catch (Exception e) 
      {
         System.out.println("Exception" + e.toString());
      }
   } // public void saveWeights()

/*
 * The loadWeights() method loads in weights from an external file.
 */
   public void loadWeights() throws Exception
   {
      int m, k, j, i;

      try 
      {
         FileInputStream fis = new FileInputStream(initialWeightsFile);
         DataInputStream dis = new DataInputStream(fis);

         for (m = 0; m < nInputs; m++)
         {
            for (k = 0; k < nHidden1; k++)
            {
               mkWeights[m][k] = dis.readDouble();
               // System.out.println(mkWeights[k][j]);
            }
         } // for (k = 0; k < nInputs; k++)

         for (k = 0; k < nHidden1; k++)
         {
            for (j = 0; j < nHidden2; j++)
            {
               kjWeights[k][j] = dis.readDouble();
               // System.out.println(mkWeights[k][j]);
            }
         } // for (k = 0; k < nInputs; k++)

         for (j = 0; j < nHidden2; j++)
         {
            for (i = 0; i < nOutputs; i++)
            {
               jiWeights[j][i] = dis.readDouble();
            }
         } // for (j = 0; j < nHidden; j++)
      } // try
      catch (IOException e)
      {
         System.out.println("Exception " + e.toString());
      }
   } // public void loadWeights()

/*
 * 
 */
   public void readConfigFile() throws Exception
   {
      int testCase;

      try (BufferedReader reader = new BufferedReader(new FileReader(configFileName)))
      {
         String line = reader.readLine();
         StringTokenizer tokenizer = new StringTokenizer(line);
         String token = tokenizer.nextToken();

         if (token.equals("T"))
         {
            training = true;
         }
         else if (token.equals("R"))
         {
            training = false;
         }
         else 
         {
            throw new Exception("Configuration file does not follow the format.");   
         }

         line = reader.readLine();
         tokenizer = new StringTokenizer(line);
         token = tokenizer.nextToken();

         if (token.equals("R"))
         {
            randomize = true;
         }
         else if (token.equals("P"))
         {
            randomize = false;
            loadWeightsFromFile = true;
         }
         else if (tokenizer.nextToken().equals("M"))
         {
            randomize = false;
            loadWeightsFromFile = false;
         }
         else 
         {
            throw new Exception("Configuration file does not follow the format.");   
         }

         line = reader.readLine();
         tokenizer = new StringTokenizer(line);

         nInputs = Integer.parseInt(tokenizer.nextToken());
         nHidden1 = Integer.parseInt(tokenizer.nextToken());
         nHidden2 = Integer.parseInt(tokenizer.nextToken());
         nOutputs = Integer.parseInt(tokenizer.nextToken());

         line = reader.readLine();
         tokenizer = new StringTokenizer(line);

         testCases = Integer.parseInt(tokenizer.nextToken());

         line = reader.readLine();
         tokenizer = new StringTokenizer(line);

         for (testCase = 0; testCase < testCases; testCase++)
         {
            line = reader.readLine(); // need to read over truth table lines as it is going to be dealt with in allocateMemory().
         }

         tokenizer = new StringTokenizer(line);
         maxIterations = Integer.parseInt(tokenizer.nextToken());

         line = reader.readLine();
         tokenizer = new StringTokenizer(line);
         errorCutoff = Double.parseDouble(tokenizer.nextToken());

         line = reader.readLine();
         tokenizer = new StringTokenizer(line);
         lambda = Double.parseDouble(tokenizer.nextToken());

         line = reader.readLine();
         tokenizer = new StringTokenizer(line);
         randMin = Double.parseDouble(tokenizer.nextToken());
         randMax = Double.parseDouble(tokenizer.nextToken());
         
         line = reader.readLine();
         if (line != null)
         {
            saveWeightsToFile = true;
            saveWeightsFile = line;
            line = reader.readLine();
            if (line != null && loadWeightsFromFile)
            {
               initialWeightsFile = line;
            }
            else if (loadWeightsFromFile && line == null)
            {
/*
 * If no initial weights file is given when preloading weights, it will preload from the saved weights file.
 */
               initialWeightsFile = saveWeightsFile;
            } // else if (loadWeightsFromFile && line == null)
         } // if (line != null)
      } // try (BufferedReader reader = new BufferedReader(new FileReader(configFileName)))
      catch (Exception e)
      {
         System.out.println("Exception " + e.toString());
      }
   } // public void readConfigFile()
} // public class ABCBackprop